import csv
import psycopg2
s=input()
conn = psycopg2.connect(database="postgres", user="postgres", password="Mouni@123",port="5432",host="localhost")
conn.autocommit = True
print("database connected")
cur=conn.cursor()
f=open("config.txt","r")
file1=f.read()
key=[]
row=None
f=0
company=None
t=[]
file2=file1.split("\n")
for i in file2:
    if(i=='statistics' or i=='profile' or i=='finances'):
        row=i
    elif(':' in i):
        ii=i.split(":")
        if('_' in ii[0].strip()):
            st=ii[0].split("_")
            q=st[0]+' '+st[1]
            if(s.__contains__(q.strip())):
                key=q.strip()
                f=1
                t=row
        else:
            if(s.__contains__(ii[0].strip())):
                key=ii[0].strip()
                t=row
if(f==1):
    key=key.replace(" ","_")
print(key)
print(t)
with open("people1.csv", 'r') as csvfile:
    reader = csv.reader(csvfile)
    for rows in reader:
        if(rows[0]!=''):
            j=rows[0]
            if(s.__contains__(j.strip())):
                company=j
print(company)
if(t=='profile'):
    ticker_name = "prof_ticker"
elif(t=='finances'):
    ticker_name="fin_ticker"
else:
    ticker_name="stat_ticker"
    
cur.execute("SELECT "+key+" from tick."+t+" WHERE "+ticker_name+"='"+company+"'")
rows = cur.fetchall()
for z in rows:
    print(z[0])
    
    
        
