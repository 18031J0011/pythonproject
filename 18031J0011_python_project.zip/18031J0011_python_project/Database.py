import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT # <-- ADD THIS LIN
conn = psycopg2.connect(database="postgres", user="postgres", password="Mouni@123",port="5432",host="localhost")
print("database connected")
conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT) # <-- ADD THIS LINE
cur=conn.cursor()
#
cur.execute("select count(*) =0 from pg_catalog.pg_namespace where nspname='tick'")
#cur.execute("select count(*) =0 from pg_catalog.pg_database where datname='tickers'")
not_exists_row = cur.fetchone()
not_exists = not_exists_row[0]
if not_exists:
#    cur.execute("CREATE DATABASE  tickers;")
    cur.execute("CREATE SCHEMA TICK ")
try:
    
    print("database Created....")
   # conn = psycopg2.connect(database="tickers", user="postgres", password="Mouni@123",port="5432",host="localhost")
    #print("database connected")
#    cur.execute("\C tickers")
    #cur.execute("CREATE TABLE tick.profile(prof_ticker TEXT PRIMARY KEY,name TEXT,Address char(100),Pno char(15),web TEXT,sector TEXT, industry TEXT,Full_time integer,bus_sum char(20));")
    cur.execute("CREATE TABLE tick.statistics (sno integer, stat_ticker TEXT PRIMARY KEY,marketcap TEXT,enterprise_value TEXT,return_on_assets TEXT, Total_cash TEXT,operating_cash_flow TEXT,levered_free_cash_flow TEXT, Total_debt TEXT,Current_ratio TEXT,gross_profit TEXT,profit_margin TEXT);")
    #cur.execute("CREATE TABLE tick.finances(Fin_ticker TEXT PRIMARY KEY,Total_rev TEXT,Cost_rev TEXT,Income_beftax TEXT,Net_income TEXT);")
    
except (Exception, psycopg2.DatabaseError) as error:
        print(error)
finally:
    if conn is not None:
        conn.close()
 

