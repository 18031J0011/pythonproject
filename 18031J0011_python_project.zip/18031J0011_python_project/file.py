import requests
import os
from bs4 import BeautifulSoup
import csv
name=[]
os.stat("Tickers")       

page = requests.get('https://finance.yahoo.com/trending-tickers')

# Create a BeautifulSoup object
soup = BeautifulSoup(page.text, 'html.parser')
#f = csv.writer(open('z-artist-names.csv', 'w'))
#f.writerow(['symbol', 'name'])
artist_name_list = soup.find_all(class_='data-col0 Ta(start) Pstart(6px) Pend(15px)')
name_list=soup.find_all(class_='data-col1 Ta(start) Pstart(10px) Miw(180px)')
#print(artist_name_list )
i=0
with open('people1.csv', 'w') as writeFile:
    writer = csv.writer(writeFile)
    for artist_list_items in artist_name_list:
        artist_name_list_items = artist_list_items.find_all('a')
        for artist_name in artist_name_list_items:
            if i<6:
                writer.writerow([artist_name.contents[0],name_list[i].contents[0]])
                name=artist_name.contents[0]
               
                try:
                    os.makedirs(os.path.join("Tickers",name))
                except:
                    os.stat("Tickers/"+name)
            
                    page1=requests.get('https://finance.yahoo.com/quote/'+name+'?p='+name)
                    soup1=BeautifulSoup(page1.text,'html.parser')
                    f1=open("Tickers/"+name+"/summary.html","w")
                   # print(f1.name)
                    f1.write(str(soup1.encode('utf-8')))

                    page2=requests.get('https://finance.yahoo.com/quote/'+name+'/profile?p='+name)
                    soup2=BeautifulSoup(page2.text,'html.parser')
                    f2=open("Tickers/"+name+"/profile.html","w")
                    f2.write(str(soup2.encode('utf-8')))

                    page3=requests.get('https://finance.yahoo.com/quote/'+name+'/key-statistics?p='+name)
                    soup3=BeautifulSoup(page3.text,'html.parser')
                    f3=open("Tickers/"+name+"/statistics.html","w")
                    f3.write(str(soup3.encode('utf-8')))

                    page4=requests.get('https://finance.yahoo.com/quote/'+name+'/financials?p='+name)
                    soup4=BeautifulSoup(page4.text,'html.parser')
                    f4=open("Tickers/"+name+"/financials.html","w")
                    f4.write(str(soup4.encode('utf-8')))
                i = i +1

