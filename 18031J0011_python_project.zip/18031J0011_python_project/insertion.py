import re
import requests
from bs4 import BeautifulSoup
import psycopg2
import csv
count=0
str_emp=""
rt=""
income_str=" "
sno = 0
conn = psycopg2.connect(database="postgres", user="postgres", password="Mouni@123",port="5432",host="localhost")
conn.autocommit = True
print("database connected")
cur=conn.cursor()

with open("people1.csv", 'r') as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        if(row[0]!=''):
            x=row[0]
            print("hjkl",x)
            str_emp=""
            rt = ""
            income_str = " "
            count=count+1
            mkt = ""
            url='C:/Users/Raju/Documents/18031J0011_python_project/Tickers/'+x+'/profile.html'
            url1='C:/Users/Raju/Documents/18031J0011_python_project/Tickers/'+x+'/financials.html'
            ur2='C:/Users/Raju/Documents/18031J0011_python_project/Tickers/'+x+'/statistics.html'
            print(url)
#            page = requests.get(url)
#            page1 = requests.get(url1)
#            page2 = requests.get(url2)
            soup = BeautifulSoup(open(url), 'html.parser')
            soup4=BeautifulSoup(open(url1),'html.parser')
            soup5 = BeautifulSoup(open(ur2), 'html.parser')
#1. Attributes for Profiles Table
#getting name from html page
            soup1=BeautifulSoup(str(soup.find_all(class_="Fz(m) Mb(10px)")),'html.parser')
            name=soup1.get_text().strip("[]")
            print(name)
#getting address from html page
            soup2 = BeautifulSoup(str(soup.find_all(class_="D(ib) W(47.727%) Pend(40px)")), 'html.parser')
            address = soup2.get_text().strip("[]")
            urlless_string = re.sub(r'http\S+', '', address)
            print(urlless_string)
#getting phone number from html page
            soup3= BeautifulSoup(str(soup.find_all(class_="D(ib) W(47.727%) Pend(40px)")), 'html.parser')
            mnum=soup3.find_all('a')
            for j in mnum:
                stri=j.get_text()
            #st=stri.split("\n")
                mobile = re.sub(r'http\S+', '', stri)
            print(mobile)
#getting website from html page
            emails = BeautifulSoup(str(soup.find_all(class_="D(ib) W(47.727%) Pend(40px)")), 'html.parser')
            emailid = emails.get_text().strip("[]")
            emailids = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', emailid)
            email = str(emailids).strip("[],''")
#getting sector from html page
            sectors = BeautifulSoup(str(soup.find_all(class_="Fw(600)")), 'html.parser')
            sector1 = sectors.get_text().strip("[]")
            sectr = (sector1.split(","))
            sectorrs = sectr[0]
#getting industry from html page
            print(sectr)
            industries = sectr[1]
            print(industries)
#getting full time  from html page
            ft_emp = BeautifulSoup(str(soup.find_all(class_="Fw(600)")), 'html.parser')
            emp = ft_emp.get_text().strip("[]")
# print(type(emp))
            emp1=re.findall('[0-9]',emp)
            for z in emp1:
                str_emp+=z
                print(str_emp)

#2. Attributes for Finance Table
# getting tottal revenue from html page
            tr = BeautifulSoup(str(soup4.find_all(class_="Fz(s) Ta(end) Pstart(10px)")), 'html.parser')
            revenue = tr.get_text().strip("[]")
            print("reve..",revenue)
            r=list(revenue)
        #print(r)
            for q in r:
                rt+=q
        #print(rt)
            rtr=rt.split(" ")
            total_revenue=rtr[3].strip(",")
            print(total_revenue)

        # getting cost revenue from html page
            cost_revenue=rtr[7].strip(",")
            print(cost_revenue)

        # getting INCOME_BEFORE_TAXfrom html page
            income_before=rtr[35].strip(",")
            print(income_before)

        # getting NET_INCOME html page
            tr1 = BeautifulSoup(str(soup4.find_all(class_="Fw(600) Ta(end) Py(8px) Pt(36px)")), 'html.parser')
            income= tr1.get_text().strip("[]")
            income_list=list(income)
            for il in income_list:
                income_str+=il
        #print(income_str)
        # print("inc",income_str[4])
            income_final=income_str.split(" ")
            total_income_revenue = income_final[len(income_final)-1].strip(",")
        #print(total_income_revenue)
# 3. Attributes for statisticsTable
            sno+=1
        # getting market cap html page
            mkt_soup = BeautifulSoup(str(soup5.find_all(class_="Fz(s) Fw(500) Ta(end)")), 'html.parser')
            mkt_income = mkt_soup.get_text().strip("[]")
            print("market ",mkt_income)
            mkt_list=mkt_income.split(",")
            market=mkt_list[0]

        # getting enterprise html page
            enterprise=mkt_list[1]
        # getting return on assets html page
            return_assets = mkt_list[15]
            totalcash=mkt_list[25]
            print(totalcash)
            operate_cash=mkt_list[31]
            print(operate_cash)
            operate_cash=mkt_list[32]
            free_cash=mkt_list[32]
            free_cash= mkt_list[33]
            print(free_cash)
            total_debit=mkt_list[27]
            current_ratio=mkt_list[29]
            profiit=mkt_list[20]
            profiit=mkt_list[21]
            margin=mkt_list[13]
            profiit = mkt_list[14]
        #inserting values into Profiles table database
            
            
            #cur.execute("INSERT INTO tick.profile (prof_ticker,name,address,pno,web,sector,industry,full_time,bus_sum) VALUES ('"+x+"','"+name+"','"+urlless_string+"','"+mobile+"','"+email+"','"+sectorrs+"','"+industries+"',"+str_emp+",'"+mobile+"')");
            #print("INSERT INTO tick.finances (fin_ticker, total_rev, cost_rev,income_beftax,net_income) VALUES('"+x+"','"+total_revenue+"','"+cost_revenue+"','"+income_before+"','"+total_income_revenue+"')");
            #cur.execute("INSERT INTO tick.finances (fin_ticker, total_rev, cost_rev,income_beftax,net_income) VALUES('"+x+"','"+total_revenue+"','"+cost_revenue+"','"+income_before+"','"+total_income_revenue+"')");
            print("INSERT INTO tick.statistics (sno,stat_ticker,marketcap,enterprise_value,profit_margin,return_on_assets,gross_profit,total_cash,total_debt,current_ratio,operating_cash_flow,levered_free_cash_flow) VALUES("+str(sno)+",'"+x+"','"+market+"','"+enterprise+"','"+return_assets+"','"+totalcash+"','"+operate_cash+"','"+free_cash+"','"+total_debit+"','"+current_ratio+"','"+profiit+"','"+margin+"')");
            cur.execute("INSERT INTO tick.statistics (sno,stat_ticker,marketcap,enterprise_value,profit_margin,return_on_assets,gross_profit,total_cash,total_debt,current_ratio,operating_cash_flow,levered_free_cash_flow) VALUES("+str(sno)+",'"+x+"','"+market+"','"+enterprise+"','"+return_assets+"','"+totalcash+"','"+operate_cash+"','"+free_cash+"','"+total_debit+"','"+current_ratio+"','"+profiit+"','"+margin+"')");
            print("inserted sucessfully")
conn.close()
